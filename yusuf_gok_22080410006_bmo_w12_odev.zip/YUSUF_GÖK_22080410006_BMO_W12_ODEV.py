# create a dictionary named sinav_result and transfer the table to it
# keys will be table headers (e.g. name, gender, etc.)
sinav_result = {
    'Ayse K.': {'gender': 'K', 'visa': 80, 'final': 90},
    'Ahmed M.': {'gender': 'TO', 'visa': 60, 'final': 50},
    'Nuri C.': {'gender': 'TO', 'visa': 77, 'final': 53},
    'Nawar T.': {'gender': 'TO', 'visa': 25, 'final': 100},
    'Susan T.': {'gender': 'K', 'visa': 36, 'final': 98},
    'Ala B.': {'gender': 'K', 'visa': 75, 'final': 66},
}

# define a function that calculates the passing grade and saves it to the sinav_result dictionary
def save_passing_grade(sinav_result):
    for name, scores in sinav_result.items():
        visa = scores['visa']
        final = scores['final']
        passing_grade = (0.3 * visa) + (0.7 * final)
        scores['passing_grade'] = passing_grade

# calculate and save the passing grades
save_passing_grade(sinav_result)

# ask the user to enter 2 new records
print('Enter 2 new records:')
for i in range(2):
    print('Record', i+1)
    name = input('Enter name: ')
    gender = input('Enter gender: ')
    visa = float(input('Enter visa grade: '))
    final = float(input('Enter final grade: '))
    sinav_result[name] = {'gender': gender, 'visa': visa, 'final': final}

# update the table with new records and print it
save_passing_grade(sinav_result)
print('Updated table:')
for name, scores in sinav_result.items():
    print(name, scores)