#Soru 1
 
sinav_sonuc = {"İsim": ["Ayşe K.","Ahmet M.","Nuri C.","Nawar T.","Suzan T.","Ala B."],"Cinsiyet":["K","E","E","E","K","K"],"Matematik":[80,60,77,25,36,75],"Türkçe":[90,50,53,100,98,66]}

#Soru 2

ort_kadin =0
ort_erkek =0
ort_turkce =0
for i in range(6):
	if sinav_sonuc["Cinsiyet"][i] == "K":
		ort_kadin+=sinav_sonuc["Matematik"][i]
	else:
		ort_erkek+=sinav_sonuc["Matematik"][i]
	ort_turkce+=sinav_sonuc["Türkçe"][i]
		
print("Kadın Matematik Ortalaması: "+str(ort_kadin/3))
print("Erkek Matematik Ortalaması: "+str(ort_erkek/3))
print("Sınıf Türkçe Ortalaması: "+str(ort_turkce/6))

#Soru 3
kadin = 0
erkek = 0
for i in range(6):
	if sinav_sonuc["Cinsiyet"][i] == "K":
		if kadin <= sinav_sonuc["Türkçe"][i]:
			kadin = sinav_sonuc["Türkçe"][i]
	else:
		if erkek <= sinav_sonuc["Türkçe"][i]:
		   erkek=sinav_sonuc["Türkçe"][i]
		   
print("Kadın En Yüksek Türkçe Notu: "+str(kadin))
print("Erkek En Yüksek Türkçe Notu: "+str(erkek))